import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Table } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faFilter, faXmark } from "@fortawesome/free-solid-svg-icons";
import { Form } from "react-bootstrap";
import { faPen } from "@fortawesome/free-solid-svg-icons";

function UserTable() {
   
  const  [isFilter, setisFilter] = useState(false);

  const openFilter = () =>{
    setisFilter(!isFilter)
  }

  const closeFilter = ()=>{
    setisFilter(!isFilter)
  }
  return (
    // <div className="main" id="main">

    //   <div className="container-fluid">
    //   <div className="row gap my-3 justify-center">
    //     <div className="col-lg-4 col-md-6 col-sm-12 ">
    //       <div className="p-2 text-center w-[95%] bg-white rounded-lg mr-1 my-2" >
    //          <h3 className="text-[#2f007e] text-[36px]">2500</h3>
    //          <p className="text-2xl">Total Users</p>
    //       </div>
    //     </div>
    //     <div className="col-lg-4 col-md-6 col-sm-12 ">
    //       <div className="p-2 text-center w-[95%] bg-white rounded-lg mx-1 my-2" >
    //          <h3 className="text-[#14c80f73] text-[36px]">1000</h3>
    //          <p className="text-2xl">Active User</p>
    //       </div>
    //     </div>
    //     <div className="col-lg-4 col-md-6 col-sm-12 ">
    //       <div className="p-2 text-center w-[95%] bg-white rounded-lg mx-1 my-2" >
    //          <h3 className="text-[#bbc400eb] text-[36px]">1000</h3>
    //          <p className="text-2xl">Deactive Users</p>
    //       </div>
    //     </div>
    //   </div>
    //     <div className="row justify-between">
    //     <div className="col-lg-4 col-md-6 col-sm-6">
    //     <h3 className="text-4xl text-[#2f007e]">USERS</h3></div>
    //       <div className="col-lg-2 col-md-6 col-sm-6">
    //         <Link className="bg-[#2f007e] rounded-lg py-3 px-6 text-white">
    //           Add User
    //         </Link>
    //       </div>
    //     </div>
    //   </div>
    //   <Table>
    //     <thead>
    //       <tr>
    //         <th>#</th>
    //         <th>name</th>
    //         <th>Joined</th>
    //         <th colSpan={2}>Status</th>
    //       </tr>
    //     </thead>
    //     <tbody>
    //       <tr>
    //         <td>1</td>
    //         <td>David</td>
    //         <td>10-20-2024</td>
    //         <td className="flex ">
    //           <span className="border-green-700  w-fit p-2 rounded-full border-2 bg-[#14c80f73] text-center">
    //             Active
    //           </span>
    //         </td>
    //         <td className="">
    //           <button className="bg-red-600 rounded-lg px-3 py-2 text-white">
    //             Delete
    //           </button>
    //         </td>
    //       </tr>
    //       <tr>
    //         <td>2</td>
    //         <td>Michle</td>
    //         <td>10-20-2024</td>
    //         <td className="flex">
    //           <span className="border-red-600 w-fit p-2 rounded-full border-2 bg-[#ee0f0f66] text-center">
    //             Deactive
    //           </span>
    //         </td>
    //         <td>
    //           <button className="bg-red-600 rounded-lg px-3 py-2 text-white">
    //             Delete
    //           </button>
    //         </td>
    //       </tr>
    //       <tr>
    //         <td>3</td>
    //         <td>David</td>
    //         <td>10-20-2024</td>
    //         <td className="flex ">
    //           <span className="border-green-700  w-fit p-2 rounded-full border-2 bg-[#14c80f73] text-center">
    //             Active
    //           </span>
    //         </td>
    //         <td className="">
    //           <button className="bg-red-600 rounded-lg px-3 py-2 text-white">
    //             Delete
    //           </button>
    //         </td>
    //       </tr>
    //       <tr>
    //         <td>4</td>
    //         <td>David</td>
    //         <td>10-20-2024</td>
    //         <td className="flex ">
    //           <span className="border-green-700  w-fit p-2 rounded-full border-2 bg-[#14c80f73] text-center">
    //             Active
    //           </span>
    //         </td>
    //         <td className="">
    //           <button className="bg-red-600 rounded-lg px-3 py-2 text-white">
    //             Delete
    //           </button>
    //         </td>
    //       </tr>
    //       <tr>
    //         <td>5</td>
    //         <td>Michle</td>
    //         <td>10-20-2024</td>
    //         <td className="flex">
    //           <span className="border-red-600 w-fit p-2 rounded-full border-2 bg-[#ee0f0f66] text-center">
    //             Deactive
    //           </span>
    //         </td>
    //         <td>
    //           <button className="bg-red-600 rounded-lg px-3 py-2 text-white">
    //             Delete
    //           </button>
    //         </td>
    //       </tr>
    //     </tbody>
    //   </Table>
    // </div>
    <main>
      <h1>Dashboard</h1>
      <div className="date flex gap-2">
        <input
          type="input"
          name=""
          id=""
          className="py-3 w-[300px] px-10 rounded-md mr-2"
          placeholder="search..."
        />
        <button className="bg-[#2f007e] px-5 py-3 rounded-md text-white">
          Search
        </button>
      </div>
      <div className="insights">
        <div className="sales">
          <div className="middle">
            <div className="left">
              <h3>Total sales</h3>
              <h1>$25,00</h1>
            </div>
            <div className="progress">
              <svg>
                <circle cx="38" cy="38" r="36"></circle>
              </svg>
              <div className="number">
                <p>82%</p>
              </div>
            </div>
          </div>
          <small className="text-muted">last 24 hours</small>
        </div>
        <div className="expenses">
          <div className="middle">
            <div className="left">
              <h3>Total Expenses</h3>
              <h1>$14,405</h1>
            </div>
            <div className="progress">
              <svg>
                <circle cx="38" cy="38" r="36"></circle>
              </svg>
              <div className="number">
                <p>61%</p>
              </div>
            </div>
          </div>
          <small className="text-muted">last 24 hours</small>
        </div>
        <div className="income">
          <div className="middle">
            <div className="left">
              <h3>Total Income</h3>
              <h1>$27,030</h1>
            </div>
            <div className="progress">
              <svg>
                <circle cx="38" cy="38" r="36"></circle>
              </svg>
              <div className="number">
                <p>47%</p>
              </div>
            </div>
          </div>
          <small className="text-muted">last 24 hours</small>
        </div>
      </div>
      <div className="row justify-between my-5">
        <div className="col-lg-4 col-md-6 col-sm-6">
          <h3 className="text-4xl text-[#2f007e]">USERS</h3>
        </div>
        <div className="col-lg-4 col-md-6 col-sm-6 relative">
          <div className={`bg-white shadow-lg w-full rounded-md p-4 absolute ${isFilter ? 'block' : 'hidden'}`} style={{transition:'1s'}}>
            <div className="flex justify-between items-center">
              <p className="text-2xl">Filters</p>
              <button onClick={closeFilter} className="text-[#2f007e] bg-white p-2 flex items-center justify-center text-2xl rounded-lg shadow-lg">
                <FontAwesomeIcon icon={faXmark} />
              </button>
            </div>
            <div className="flex flex-col gap-2 mt-3">
            <div className="flex items-center gap-1 text-xl">
                <Form.Check // prettier-ignore
                  type={"checkbox"}
                />
                <p>Active User</p>
              </div>
              <div className="flex items-center gap-1 text-xl">
                <Form.Check // prettier-ignore
                  type={"checkbox"}
                />
                <p>Deactive User</p>
              </div>
              <div className="flex items-center gap-1 text-xl">
                <Form.Check // prettier-ignore
                  type={"checkbox"}
                />
                <p>sort By Name</p>
              </div>
              <div className="flex items-center gap-1 text-xl">
                <Form.Check // prettier-ignore
                  type={"checkbox"}
                />
                <p>Sort By Time</p>
              </div>
               <p className="text-xl my-2">Gender :-</p>
              <div className="flex items-center gap-1 text-xl">

                <Form.Check // prettier-ignore
                  type={"radio"}
                  name="gender"
                  label={"Male"}
                />
                <Form.Check // prettier-ignore
                  type={"radio"}
                  name="gender"
                  label={"Female"}
                />
                
                
              </div>
              <p className="text-xl my-2">Modified :-</p>
              <div className="flex items-center gap-1 text-xl">

                <Form.Check // prettier-ignore
                  type={"radio"}
                  name="Modified"
                  label={"Deleted"}
                />
                <Form.Check // prettier-ignore
                  type={"radio"}
                  name="Modified"
                  label={"Edited"}
                />
                
                
              </div>
            </div>
          </div>
          <div className="flex gap-2 justify-end " >
            <button onClick={openFilter} className="text-[#2f007e] bg-white p-2 text-2xl rounded-lg shadow-lg">
              <FontAwesomeIcon icon={faFilter} />
            </button>
            <Link className="bg-[#2f007e] rounded-lg py-3 px-6 text-white">
              Add User
            </Link>
          </div>
        </div>
      </div>
      <Table>
        <thead>
          <tr>
            <th>#</th>
            <th>name</th>
            <th>Joined</th>
            <th colSpan={2}>Status</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td className="flex gap-2 items-center"><span>David</span> <Link className="bg-green-600 text-white p-1 rounded-md " to={'/edit-user'}><FontAwesomeIcon icon={faPen} /></Link></td>
            <td>10-20-2024</td>
            <td className="flex ">
              <span className="border-green-700  w-fit p-2 rounded-full border-2 bg-[#14c80f73] text-center">
                Active
              </span>
            </td>
            <td className="">
              <button className="bg-red-600 rounded-lg px-3 py-2 text-white">
                Delete
              </button>
            </td>
          </tr>
          <tr>
            <td>2</td>
            <td className="flex gap-2 items-center"><span>Michle</span> <Link className="bg-green-600 text-white p-1 rounded-md " to={'/edit-user'}><FontAwesomeIcon icon={faPen} /></Link></td>
            <td>10-20-2024</td>
            <td className="flex">
              <span className="border-red-600 w-fit p-2 rounded-full border-2 bg-[#ee0f0f66] text-center">
                Deactive
              </span>
            </td>
            <td>
              <button className="bg-red-600 rounded-lg px-3 py-2 text-white">
                Delete
              </button>
            </td>
          </tr>
          <tr>
            <td>3</td>
            <td className="flex gap-2 items-center"><span>David</span> <Link className="bg-green-600 text-white p-1 rounded-md " to={'/edit-user'}><FontAwesomeIcon icon={faPen} /></Link></td>
            <td>10-20-2024</td>
            <td className="flex ">
              <span className="border-green-700  w-fit p-2 rounded-full border-2 bg-[#14c80f73] text-center">
                Active
              </span>
            </td>
            <td className="">
              <button className="bg-red-600 rounded-lg px-3 py-2 text-white">
                Delete
              </button>
            </td>
          </tr>
          <tr>
            <td>4</td>
            <td className="flex gap-2 items-center"><span>David</span> <Link className="bg-green-600 text-white p-1 rounded-md " to={'/edit-user'}><FontAwesomeIcon icon={faPen} /></Link></td>
            <td>10-20-2024</td>
            <td className="flex ">
              <span className="border-green-700  w-fit p-2 rounded-full border-2 bg-[#14c80f73] text-center">
                Active
              </span>
            </td>
            <td className="">
              <button className="bg-red-600 rounded-lg px-3 py-2 text-white">
                Delete
              </button>
            </td>
          </tr>
          <tr>
            <td>5</td>
            <td className="flex gap-2 items-center"><span>Michle</span> <Link className="bg-green-600 text-white p-1 rounded-md " to={'/edit-user'}><FontAwesomeIcon icon={faPen} /></Link></td>
            <td>10-20-2024</td>
            <td className="flex">
              <span className="border-red-600 w-fit p-2 rounded-full border-2 bg-[#ee0f0f66] text-center">
                Deactive
              </span>
            </td>
            <td>
              <button className="bg-red-600 rounded-lg px-3 py-2 text-white">
                Delete
              </button>
            </td>
          </tr>
        </tbody>
      </Table>
    </main>
  );
}

export default UserTable;
